import getRunsThisSeason from "./1.js"
import isFreshStart from "./2.js"
import isPostMarkPick from "./3.js"
import isTopMarks from "./4.js"
import isDroppingDown from "./5.js"

//  console.log(getRunsThisSeason(1012489,"2019-12-07"))
//  console.log(isFreshStart(1012489))
//  console.log("distance RPR to 2nd max horse = " + isPostMarkPick(2008517))
//  console.log(isTopMarks(1581038))
//  console.log(isDroppingDown(1581038,false))

