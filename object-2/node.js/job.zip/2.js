import {execIsFirstTimeNewTrainer} from "./transform-data.js"

export default function isFirstTimeNewTrainer(horseId){
    return execIsFirstTimeNewTrainer(horseId)
}