import {todayRaceObj} from "./data.js"
import {getSortedFormByRaceDate,findRunnerWithId,getDaysDifference} from "./shared.js"

const restPeroid = 150; // in days
const withinPeroid = 21 // in days


 // comingon functions

 export function isRPRgreater(horseId,difference){
    const runnerFormTable = getSortedFormByRaceDate(horseId);
    return (runnerFormTable[0].lRPR - runnerFormTable[1].lRPR >= difference)// ||  (runnerFormTable[runnerFormTable.length-2].lRPR - runnerFormTable[runnerFormTable.length-1].lRPR >= difference)
                                                                            // I'm not sure if I should check latest or newest races
 }

 export function isTodayPeroidTestPassed(horseId){


    const todayDate = new Date(todayRaceObj.todayRace.raceDate);

    const runnerFormTable = getSortedFormByRaceDate(horseId);

    const isRestPeroidTrue = (getDaysDifference(runnerFormTable[0].lRaceDate,runnerFormTable[1].lRaceDate) >= restPeroid);
  
    const isWithinPeroidTrue = (getDaysDifference(todayDate,runnerFormTable[0].lRaceDate) <= withinPeroid)


    const hasRunToday = todayRaceObj.runnerIds.some(id=>id == horseId)
  
    return hasRunToday && isWithinPeroidTrue && isRestPeroidTrue 
 }

export function isFormTablePeroidTestPassed(horseId){
 
    const runnerFormTable = getSortedFormByRaceDate(horseId);

    for(let i=2;i<runnerFormTable.length ;++i){
        if(getDaysDifference(runnerFormTable[i-1].lRaceDate,runnerFormTable[i].lRaceDate)>= restPeroid){
         
            if(getDaysDifference(runnerFormTable[i-2].lRaceDate,runnerFormTable[i-1].lRaceDate) <= withinPeroid){
                return true
            }
        }
    }
    return false
}



///////  maiden functions


export function hasAnyWins(horseId){
    const runner = findRunnerWithId(horseId)
        
        return runner.formTable.some(race=>race.lFinalPos === "1")
}

export function getRunnerRaces(horseId,amount){
    const races = [...getSortedFormByRaceDate(horseId)]
    races.length = amount

    return races;
}

export function hasPassedPositionsCondition(horseId){
    const positions = ["2","3"]

    const races = getRunnerRaces(horseId,3)
    
   return races.filter(race=>{ // could be reduce used
        return positions.some(position=>position === race.lFinalPos)
    }).length >= 2
}

export function checkIfIsFlat(isFlat){
    if(isFlat){ // I don't know if I understand you in this export function
        return todayRaceObj.todayCode === "flat"
    }

        return todayRaceObj.todayCode !== "flat"
    
}

////





