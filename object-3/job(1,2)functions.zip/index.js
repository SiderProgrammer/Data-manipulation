
import ComingOn from "./1.js"
import MaidenKAD from "./2.js"

console.log(ComingOn(1185805))

console.log(MaidenKAD(875092,true))