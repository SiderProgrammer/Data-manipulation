import {execCombinationRank1} from "./transform-data.js"

export default function CombinationRank1(){
    execCombinationRank1()
}