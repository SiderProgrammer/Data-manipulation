import {convertBeatenByDistances} from "./transform-data.js"
import ComingOn from "./1.js"
import MaidenKAD from "./2.js"
import CombinationRank1 from "./3.js"

convertBeatenByDistances()

console.log(ComingOn(1185805))

console.log(MaidenKAD(875092,false))

CombinationRank1()